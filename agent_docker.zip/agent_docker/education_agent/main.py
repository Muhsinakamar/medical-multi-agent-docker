from fastapi import FastAPI
from pydantic import BaseModel, Field


app = FastAPI(title="Education Agent")


class PatientCase(BaseModel):
    patient_name: str = Field(default="Guest")
    age: int = Field(ge=0, le=120)
    symptoms: str = Field(min_length=3)
    question: str = Field(default="What should I do next?")


def build_guidance(symptoms: str) -> list[str]:
    text = symptoms.lower()
    tips: list[str] = []

    if "fever" in text:
        tips.append("Drink fluids, rest, and monitor temperature.")
    if "cough" in text:
        tips.append("Warm fluids and avoiding smoke may help with mild cough symptoms.")
    if "headache" in text:
        tips.append("Rest, hydration, and reduced screen time may help a mild headache.")
    if "chest pain" in text or "shortness of breath" in text:
        tips.append("Chest pain or breathing trouble should be evaluated urgently.")

    if not tips:
        tips.append("Track symptoms, note changes, and discuss persistent concerns with a clinician.")

    tips.append("Use this project only as a technical demo, not as real medical advice.")
    return tips


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/educate")
async def educate(case: PatientCase) -> dict:
    guidance = build_guidance(case.symptoms)

    answer = (
        f"For the question '{case.question}', the demo suggests starting with supportive care "
        "if symptoms are mild, and getting professional care sooner if symptoms intensify."
    )

    return {
        "guidance": guidance,
        "answer": answer,
    }
