from fastapi import FastAPI
from pydantic import BaseModel, Field


app = FastAPI(title="Triage Agent")

EMERGENCY_SIGNS = [
    "chest pain",
    "shortness of breath",
    "severe bleeding",
    "loss of consciousness",
    "stroke",
    "one-sided weakness",
]

URGENT_SIGNS = [
    "high fever",
    "fever",
    "vomiting",
    "dehydration",
    "infection",
    "severe pain",
    "persistent cough",
]


class PatientCase(BaseModel):
    patient_name: str = Field(default="Guest")
    age: int = Field(ge=0, le=120)
    symptoms: str = Field(min_length=3)
    question: str = Field(default="What should I do next?")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/analyze")
async def analyze(case: PatientCase) -> dict:
    text = case.symptoms.lower()
    reasons: list[str] = []

    emergency_hits = [item for item in EMERGENCY_SIGNS if item in text]
    urgent_hits = [item for item in URGENT_SIGNS if item in text]

    if emergency_hits:
        reasons.append(f"Possible red-flag symptoms detected: {', '.join(emergency_hits)}.")
        urgency = "emergency"
        next_step = "Seek emergency care immediately or call local emergency services."
    elif urgent_hits or (case.age >= 65 and "fever" in text):
        if urgent_hits:
            reasons.append(f"Symptoms need prompt review: {', '.join(urgent_hits)}.")
        if case.age >= 65 and "fever" in text:
            reasons.append("Older age with fever can raise risk and deserves timely evaluation.")
        urgency = "urgent"
        next_step = "Arrange a same-day or next-day clinician review."
    else:
        reasons.append("No emergency keywords were detected in this simple demo.")
        urgency = "routine"
        next_step = "Home care may be reasonable, but monitor symptoms and escalate if they worsen."

    return {
        "urgency": urgency,
        "reasons": reasons,
        "next_step": next_step,
    }
