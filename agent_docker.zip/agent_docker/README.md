# Simple Medical Multi-Agent Demo

This is a very small learning project that shows how a **multi-agent medical-style application** can run with Docker.

It includes:

- `coordinator`: accepts the patient case and combines the outputs
- `triage-agent`: decides whether the case looks routine, urgent, or emergency
- `education-agent`: gives simple educational guidance

## Important note

This project is for **demo and learning purposes only**. It does **not** provide real medical advice.

## Stack

- Python
- FastAPI
- Docker Compose

## Run it

```bash
docker compose up --build
```

Then open:

[http://localhost:8000](http://localhost:8000)

## Example flow

1. Enter a patient name, age, symptoms, and a question.
2. The `coordinator` sends the case to both agents.
3. The UI shows:
   - triage urgency
   - suggested next step
   - educational guidance

## Project structure

```text
.
|-- coordinator/
|   |-- main.py
|   `-- static/index.html
|-- triage_agent/
|   `-- main.py
|-- education_agent/
|   `-- main.py
|-- Dockerfile
|-- docker-compose.yml
`-- requirements.txt
```

## API example

```bash
curl -X POST http://localhost:8000/api/consult \
  -H "Content-Type: application/json" \
  -d '{
    "patient_name": "Asha",
    "age": 34,
    "symptoms": "Fever and cough for two days",
    "question": "Should I rest at home?"
  }'
```
