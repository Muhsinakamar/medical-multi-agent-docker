import asyncio
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field


TRIAGE_URL = os.getenv("TRIAGE_URL", "http://localhost:8001/analyze")
EDUCATION_URL = os.getenv("EDUCATION_URL", "http://localhost:8002/educate")
STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Medical Multi-Agent Demo")


class PatientCase(BaseModel):
    patient_name: str = Field(default="Guest")
    age: int = Field(ge=0, le=120)
    symptoms: str = Field(min_length=3)
    question: str = Field(default="What should I do next?")


@app.get("/")
async def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/consult")
async def consult(patient_case: PatientCase) -> dict:
    payload = patient_case.model_dump()

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            triage_response, education_response = await asyncio.gather(
                client.post(TRIAGE_URL, json=payload),
                client.post(EDUCATION_URL, json=payload),
            )
        except httpx.HTTPError as exc:
            raise HTTPException(status_code=502, detail=f"Agent call failed: {exc}") from exc

    if triage_response.status_code >= 400:
        raise HTTPException(status_code=502, detail="Triage agent returned an error")
    if education_response.status_code >= 400:
        raise HTTPException(status_code=502, detail="Education agent returned an error")

    triage = triage_response.json()
    education = education_response.json()

    return {
        "patient": payload["patient_name"],
        "summary": f"{payload['patient_name']} reported {payload['symptoms']}.",
        "triage": triage,
        "education": education,
        "disclaimer": "Demo only. This project is not a substitute for professional medical care.",
    }